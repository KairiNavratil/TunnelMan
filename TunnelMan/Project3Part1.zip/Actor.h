#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// main object class
class Actor : public GraphObject
{
public:
    Actor(int imageID, int startX, int startY, StudentWorld* world, Direction dir = right, double size = 1.0, unsigned int depth = 0) : GraphObject(imageID, startX, startY, dir, size, depth), m_world(world), m_isAlive(true)
    {
        setVisible(true);
    }

    virtual void doSomething() = 0;

    bool isAlive() const
    {
        return m_isAlive;
    }

    void setDead()
    {
        m_isAlive = false;
    }

    StudentWorld* getWorld() const
    {
        return m_world;
    }

private:
    StudentWorld* m_world;
    bool m_isAlive;
};

class Earth : public Actor
{
public:
    Earth(int startX, int startY, StudentWorld* world) : Actor(TID_EARTH, startX, startY, world, right, 0.25, 3) {}

    virtual void doSomething() {}
};

class Tunnelman : public Actor
{
public:
    // spawn loc
    Tunnelman(StudentWorld* world) : Actor(TID_PLAYER, 30, 60, world, right, 1.0, 0) {}

    virtual void doSomething();
};

#endif