#include "Actor.h"
#include "StudentWorld.h"
#include "GameConstants.h"

void Tunnelman::doSomething()
{
    if (!isAlive())
    {
        return;
    }

    // check for dirt overlap
    if (getWorld()->removeEarth(getX(), getY()))
    {
        getWorld()->playSound(SOUND_DIG);
    }

    // handle keys
    int ch;
    if (getWorld()->getKey(ch))
    {
        switch (ch)
        {
        case KEY_PRESS_LEFT:
            if (getDirection() != left)
            {
                setDirection(left);
            }
            else if (getX() > 0)
            {
                moveTo(getX() - 1, getY());
            }
            break;

        case KEY_PRESS_RIGHT:
            if (getDirection() != right)
            {
                setDirection(right);
            }
            else if (getX() < 60)
            {
                // dont go off edge
                moveTo(getX() + 1, getY());
            }
            break;

        case KEY_PRESS_UP:
            if (getDirection() != up)
            {
                setDirection(up);
            }
            else if (getY() < 60)
            {
                moveTo(getX(), getY() + 1);
            }
            break;

        case KEY_PRESS_DOWN:
            if (getDirection() != down)
            {
                setDirection(down);
            }
            else if (getY() > 0)
            {
                moveTo(getX(), getY() - 1);
            }
            break;

        case KEY_PRESS_ESCAPE:
            setDead();
            break;
        }
    }
}