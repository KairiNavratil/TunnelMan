#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
    return new StudentWorld(assetDir);
}

int StudentWorld::init()
{
    // spawn player
    m_player = new Tunnelman(this);

    // fill grid
    for (int x = 0; x < VIEW_WIDTH; x++)
    {
        for (int y = 0; y < 60; y++)
        {
            // skip the shaft
            if (x >= 30 && x <= 33 && y >= 4)
            {
                continue;
            }

            m_earth[x][y] = new Earth(x, y, this);
        }
    }

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // player
    if (m_player->isAlive())
    {
        m_player->doSomething();
    }
    else
    {
        decLives();
        return GWSTATUS_PLAYER_DIED;
    }

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    if (m_player != nullptr)
    {
        delete m_player;
        m_player = nullptr;
    }

    // clear the grid
    for (int x = 0; x < VIEW_WIDTH; x++)
    {
        for (int y = 0; y < VIEW_HEIGHT; y++)
        {
            if (m_earth[x][y] != nullptr)
            {
                delete m_earth[x][y];
                m_earth[x][y] = nullptr;
            }
        }
    }
}

bool StudentWorld::removeEarth(int x, int y)
{
    bool dug = false;

    // check 4x4 box
    for (int i = x; i < x + 4; i++)
    {
        for (int j = y; j < y + 4; j++)
        {
            // bounds check
            if (i >= 0 && i < VIEW_WIDTH && j >= 0 && j < VIEW_HEIGHT)
            {
                if (m_earth[i][j] != nullptr)
                {
                    delete m_earth[i][j];
                    m_earth[i][j] = nullptr;
                    dug = true;
                }
            }
        }
    }
    return dug;
}